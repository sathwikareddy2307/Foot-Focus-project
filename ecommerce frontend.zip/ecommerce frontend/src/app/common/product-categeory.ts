export class ProductCategeory {
    id: number;
    categoryName: string;
}
