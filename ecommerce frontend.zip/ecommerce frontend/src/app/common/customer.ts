export class Customer {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    mobile: number;
}