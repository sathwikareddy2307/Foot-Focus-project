export class Order {
    totalQuantity: number;
    totalPrice: number;
    static totalPrice: number;
}