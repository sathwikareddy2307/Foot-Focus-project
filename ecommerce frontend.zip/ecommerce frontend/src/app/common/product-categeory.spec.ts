import { ProductCategeory } from './product-categeory';

describe('ProductCategeory', () => {
  it('should create an instance', () => {
    expect(new ProductCategeory()).toBeTruthy();
  });
});
